package com.example.lab4b

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
