package com.example.quiztest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
